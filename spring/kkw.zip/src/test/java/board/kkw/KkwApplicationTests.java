package board.kkw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KkwApplicationTests {

	@Test
	void contextLoads() {
	}

}
