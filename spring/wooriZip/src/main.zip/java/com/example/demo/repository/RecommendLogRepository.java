package com.example.demo.repository;

import com.example.demo.entity.RecommendLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecommendLogRepository extends JpaRepository<RecommendLog, Long> {

}
