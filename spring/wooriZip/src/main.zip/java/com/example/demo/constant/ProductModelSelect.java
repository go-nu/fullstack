package com.example.demo.constant;

public enum ProductModelSelect {
    SMALL, MEDIUM, LARGE, DEFAULT_MODEL
}
