package com.shop.constant;

public enum Role {
    ADMIN, USER
}
